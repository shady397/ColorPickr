
# Color picker chrome extension

This project is a chrome extension where you can pick any color from your webpage or browser with your cursor. The implementation is fairly simple, to keep the project scope in check. I wanted to make a project like this to expand my knowledge in javaScript.

Technologies used:

1. HTML
2. CSS 
3. javaScript
4. JSON

## How this extension works?

The idea is simple. You can add this extension to your chrome bowser then use anytime. You just need to click on the extension. This tool can be very useful for web development. Here's video demo of this tool:
https://youtu.be/8Ic-2atUyQ4

